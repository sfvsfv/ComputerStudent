from collections import defaultdict
import importlib
import sys
importlib.reload(sys)
import warnings
warnings.filterwarnings("ignore")

class LBTrie:
    def __init__(self):
        self.trie = {}
        self.size = 0

    #添加单词
    def add(self, word):
        p = self.trie
        dicnum = 0
        word = word.strip()
        for c in word:
            if not c in p:
                p[c] = {}
            dicnum+=1
            p = p[c]


        if word != '':
            #在单词末尾处添加键值''作为标记，即只要某个字符的字典中含有''键即为单词结尾
            p[''] = ''
        if dicnum == len(word):
            return True
    #查询单词
    def search(self, word):
        p = self.trie
        word = word.lstrip()
        for c in word:
            if not c in p:
                return False
            p = p[c]
        #判断单词结束标记''
        if '' in p:
            return True
        return False
    def cipin(self):
        total = 0
        with open('冰与火之歌.txt') as f:
            b=input("请输入你要统计哪个单词的词频：")
            for line in f:
                finded = line.find(b)        #这里输入你要查询的单词，显示词频次数
                if finded != -1 and finded != 0:
                    total += 1
        print("词频为：", total)
    #打印Trie树的接口
    def output(self):
        #print '{'
        self.__print_item(self.trie)
        #print '}'
        return  self.__print_item(self.trie)

    #实现Trie树打印的私有递归函数，indent控制缩进
    def __print_item(self, p, indent=0):
        if p:
            ind = '' + '\t' * indent
            for key in p.keys():
                label = "'%s' : " % key
                print (ind + label + '{'  )
                self.__print_item(p[key], indent+1)

            print (ind + ' '*len(label) + '}'   )

def codeutil(strs):
         return strs.encode(encoding='utf-8',errors='strict')

if __name__ == '__main__':
    trie_obj = LBTrie()
    c=trie_obj.cipin()
    #添加单词
    corpus = open('冰与火之歌.txt','r')#文本内容
    # tree = open('a.txt','w+')#追加内容
    countdic = defaultdict(int)
    for record in corpus.readlines():
        recordlist = record.split(' ')
        for word in recordlist:
            check = trie_obj.add(codeutil(word))
            if check:
                countdic[word] += 1
    resortedcountdic = sorted(countdic.items(), key=lambda item: item[1], reverse=True)
    a=input("请输入你要查询的哪个单词是否存在：")
    if trie_obj.search(codeutil(a)):  # 在这输入你想要查询的单词会显示是否存在
        print('该单词存在')
    else:
        print('该单词不存在')
