# coding=gbk
"""
���ߣ�����
@ʱ��  : 2021/8/29 23:50
Ⱥ��970353786
"""
# ��Ԥ��ͼƬ
# test_img_path = ['./img/img.png', './img/img2.png','./img/img_2.png','./img/img_3.png','./img/img_4.png']

# import matplotlib.pyplot as plt
# import matplotlib.image as mpimg

# չʾ���д�ʨ��ͼƬ
# img1 = mpimg.imread(test_img_path[0])
#
# plt.figure(figsize=(10, 10))
# plt.imshow(img1)
#
# plt.axis('off')
# plt.show()


with open('tu.txt', 'r') as f:
    try:
        test_img_path=[]
        for line in f:
            test_img_path.append(line.strip())
    except:
        print('���ݼ���ʧ��')
# print(test_img_path)

import paddlehub as hub
module = hub.Module(name="resnet50_vd_animals")
# module = hub.Module(name="mobilenet_v2_animals")

import cv2
np_images =[cv2.imread(image_path) for image_path in test_img_path]
# print(np_images)
results = module.classification(images=np_images)

for result in results:
    print(result)