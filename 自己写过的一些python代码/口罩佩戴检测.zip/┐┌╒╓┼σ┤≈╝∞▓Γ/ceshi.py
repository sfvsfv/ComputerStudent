# coding=gbk
"""
���ߣ�����
@ʱ��  : 2021/8/30 0:47
Ⱥ��970353786
"""
# import matplotlib.image as im
# import matplotlib.pyplot as plt
# import os
#
# # ��Ҫ��ȡ��·��
# path_name = './detection_result'
#
# for item in os.listdir(path=path_name):
#     img = im.imread(os.path.join(path_name, item))
#     plt.imshow(img)
#     plt.show()
import cv2
with open('mask.txt', 'r') as f:
    try:
        test_img_path=[]
        for line in f:
            test_img_path.append(line.strip())
    except:
        print('���ݼ���ʧ��')
imgs =[cv2.imread(image_path) for image_path in test_img_path]
print(type(imgs))
for i in imgs:
    print(i)